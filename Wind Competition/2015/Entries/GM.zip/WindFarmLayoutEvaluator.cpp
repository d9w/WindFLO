#include "WindFarmLayoutEvaluator.h"

int WindFarmLayoutEvaluator::nEvals=0;

