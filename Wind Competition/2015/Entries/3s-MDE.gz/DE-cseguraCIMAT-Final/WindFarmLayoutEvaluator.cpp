/************************************************************************************
 Authors
 - Carlos Segura Gonzalez
 - Manuel Guillermo Lopez Buenfil
 - Mario Alberto Ocampo Pineda
 - Sergio Ivvan Valdez
 - Salvador Botello Rionda
 - Arturo Hernandez Aguirre
*************************************************************************************/


#include "WindFarmLayoutEvaluator.h"

int WindFarmLayoutEvaluator::nEvals=0;

